"""
批量生成海报脚本 v2
- 底图已预留干净的「@...」占位区域，背景是纯色 #193D5F
- 直接用纯色矩形覆盖「@...」，再绘制「@昵称」
- 字体: 白日梦想家 (bairi.ttf)
"""

import sys
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# ── 参数 ─────────────────────────────────────────────────
V1_PATH = "/home/ubuntu/upload/小东西炫耀大赛-版本一-@....png"
V2_PATH = "/home/ubuntu/upload/小东西炫耀大赛-版本二-@....png"
FONT_PATH = "/home/ubuntu/webdev-static-assets/bairi.ttf"
OUTPUT_DIR = "/home/ubuntu/posters"

# 擦除区域 & 文字中心（经精确分析）
V1_ERASE = (314, 509)
V1_TEXT_Y = 411
V1_BG = (25, 61, 95)   # #193D5F

V2_ERASE = (322, 509)
V2_TEXT_Y = 415
V2_BG = (24, 60, 94)   # #183C5E

POSTER_W = 1125
BASE_FONT_SIZE = 130
MAX_WIDTH_RATIO = 0.82  # 最大宽度比例（留边距）

os.makedirs(OUTPUT_DIR, exist_ok=True)

def generate_poster(base_path, erase_range, text_y, bg_color, nickname, out_path):
    img = Image.open(base_path).convert('RGBA')
    draw = ImageDraw.Draw(img)

    # 1. 用纯色矩形覆盖「@...」区域（全宽，确保干净）
    y1, y2 = erase_range
    draw.rectangle([(0, y1), (POSTER_W, y2)], fill=(*bg_color, 255))

    # 2. 动态字号：确保「@昵称」不超出宽度
    font_size = BASE_FONT_SIZE
    max_w = int(POSTER_W * MAX_WIDTH_RATIO)

    while font_size > 40:
        font = ImageFont.truetype(FONT_PATH, font_size)
        at_w = draw.textlength("@", font=font)
        name_w = draw.textlength(nickname, font=font)
        if at_w + name_w <= max_w:
            break
        font_size -= 4

    font = ImageFont.truetype(FONT_PATH, font_size)
    at_w = draw.textlength("@", font=font)
    name_w = draw.textlength(nickname, font=font)
    total_w = at_w + name_w

    # 居中 x，baseline y
    start_x = (POSTER_W - total_w) / 2
    baseline_y = text_y + font_size * 0.35
    stroke_w = max(8, int(font_size * 0.07))

    # 3. 黑色描边
    for seg_x, text, _ in [
        (start_x, "@", None),
        (start_x + at_w, nickname, None),
    ]:
        draw.text((seg_x, baseline_y), text, font=font,
                  fill=(17, 17, 17, 255),
                  stroke_width=stroke_w, stroke_fill=(17, 17, 17, 255),
                  anchor="ls")

    # 4. 白色 @
    draw.text((start_x, baseline_y), "@", font=font,
              fill=(255, 255, 255, 255), anchor="ls")

    # 5. 黄色昵称
    draw.text((start_x + at_w, baseline_y), nickname, font=font,
              fill=(245, 197, 24, 255), anchor="ls")

    img.save(out_path, 'PNG', optimize=True)
    print(f"  ✓ {os.path.basename(out_path)}")

# ── 主程序 ───────────────────────────────────────────────
nicknames = sys.argv[1:]

if not nicknames:
    print("用法: python3 gen_posters.py 昵称1 昵称2 ...")
    sys.exit(1)

print(f"开始生成 {len(nicknames)} 个昵称 × 2 版本 = {len(nicknames)*2} 张海报")

for nick in nicknames:
    out1 = os.path.join(OUTPUT_DIR, f"版本一-@{nick}.png")
    generate_poster(V1_PATH, V1_ERASE, V1_TEXT_Y, V1_BG, nick, out1)

    out2 = os.path.join(OUTPUT_DIR, f"版本二-@{nick}.png")
    generate_poster(V2_PATH, V2_ERASE, V2_TEXT_Y, V2_BG, nick, out2)

print(f"\n全部完成，输出目录: {OUTPUT_DIR}")
