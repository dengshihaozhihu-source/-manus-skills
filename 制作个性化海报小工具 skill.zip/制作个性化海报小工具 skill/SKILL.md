---
name: poster-generator-zhihu
description: 为知乎活动生成专属海报的完整工作流。包含两种模式：1）构建可供用户自助生成海报的 Web 小工具（用户输入昵称，实时预览并下载）；2）批量为指定昵称列表离线生成海报 PNG 并打包交付。适用场景：知乎活动邀请函、答主专属海报、圈子推广等需要个性化海报的传播策划任务。
---

# 专属海报生成器 · 工作流

## 用户需要提供的信息

### 模式一：Web 自助生成小工具

| 必须提供 | 说明 |
|---|---|
| 海报底图（PNG/JPG） | 已设计好的海报模板，昵称位置留有占位文字或空白 |
| 字体文件（TTF/OTF） | 昵称所用字体，如「白日梦想家」 |
| 昵称区域描述 | 说明昵称文字的颜色（如「白色 @ + 黄色昵称」）和大致位置 |
| 活动名称 / 圈子名称 | 用于生成下载后的引导文案 |

可选提供：多张底图（生成多版本并排预览）、设计风格偏好（如「乔布斯极简」）

### 模式二：批量离线生成

| 必须提供 | 说明 |
|---|---|
| 底图文件（1~2 张） | 已处理好的干净底图，昵称区域背景为纯色 |
| 字体文件 | 同上 |
| 昵称列表 | 用顿号分隔，如「云杉、钱程、李明殊」 |

---

## 工作流

### 模式一：Web 小工具

**Step 1：分析底图**

用 Python + PIL 定位昵称占位文字的精确坐标：

```python
from PIL import Image
import numpy as np
img = Image.open(path).convert('RGBA')
arr = np.array(img)
r, g, b = arr[:,:,0], arr[:,:,1], arr[:,:,2]
# 找黄色占位文字
yellow = (r > 180) & (g > 150) & (b < 100)
region = yellow[200:550, :]
rows = np.any(region, axis=1)
rmin, rmax = np.where(rows)[0][[0, -1]]
```

记录：擦除区域 `(y_start, y_end)`、文字中心 `y_center`、背景色 RGB。

**Step 2：生成干净底图**

若底图有占位文字需要擦除，优先用纯色矩形覆盖（避免插值模糊）：

```python
draw.rectangle([(0, y1), (W, y2)], fill=(*bg_color, 255))
```

若背景非纯色（有装饰元素），改用左右背景色插值填充，但需确认装饰元素不在文字中央区域。

**Step 3：上传静态资源**

```bash
# 底图优先转 WebP 压缩体积（quality=92，可压缩 50~80%）
manus-upload-file --webdev poster-clean.webp font.ttf
```

**Step 4：构建 Web 项目**

使用 `webdev_init_project`（web-static 模板），核心实现要点：

- 用 `new FontFace(name, url).load()` 加载字体，加入 `document.fonts`
- 用 `new Image()` 加载底图，`crossOrigin = "anonymous"`
- Canvas 绘制顺序：底图 → 纯色矩形覆盖 → 描边 → 填色
- 描边：先 `strokeText`（黑色，`lineWidth = fontSize * 0.07`），再 `fillText`
- 动态字号：总宽度超出 `POSTER_W * 0.88` 时等比缩小
- 手机端下载：bottom sheet 展示大图，提示「长按保存到相册」
- 桌面端：`canvas.toBlob` → `<a download>` 触发下载
- 加载状态：字体和图片并行加载，输入框下方显示「海报加载中……」/「字体加载中……」

**Step 5：UI 设计**

默认采用「苹果深空黑」风格：`#0d0d0f` 背景，白色 CTA 按钮，glassmorphism 输入框。多版本海报时，输入框置顶，海报并排双列，各自独立下载按钮。

---

### 模式二：批量离线生成

使用 `scripts/gen_posters.py`，修改参数后运行：

```python
V1_PATH = "底图路径"
FONT_PATH = "字体路径"
V1_ERASE = (y_start, y_end)   # 擦除区域
V1_TEXT_Y = y_center           # 文字中心
V1_BG = (R, G, B)              # 背景色
```

```bash
python3.11 gen_posters.py 云杉 钱程 李明殊 ...
# 输出命名：版本一-@昵称.png / 版本二-@昵称.png
zip -j 海报合集.zip posters/*.png
```

---

## 常见问题

**背景模糊**：插值擦除在非纯色背景上会产生色块。解决方案：让设计师提供纯色背景干净底图，或用纯色矩形直接覆盖。

**字体不显示**：FontFace 加载是异步的，必须等 `font.load()` resolve 后再绘制 Canvas。

**手机无法保存**：iOS Safari 不支持 `<a download>`，必须用 bottom sheet 展示图片让用户长按保存。

**加载慢**：底图转 WebP 可大幅压缩；字体文件大（>5MB）时考虑子集化，但生僻字会 fallback 到系统字体，活动期间慎用。
