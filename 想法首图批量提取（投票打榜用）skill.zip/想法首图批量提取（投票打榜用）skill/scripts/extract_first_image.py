"""
extract_first_image.py

从 Excel 文件中自动定位「内容正文」列，提取每行首图链接，
输出新表格，列为：内容标题 / URL_Token / 首图链接。

用法：
    python extract_first_image.py <input.xlsx> [output.xlsx]

若不指定 output，则在原文件名后加 _output 保存。
"""

import sys
import re
import openpyxl
from pathlib import Path

IMG_SRC = re.compile(r'<img[^>]+src=["\']?(https?://[^"\'>\s]+)["\']?', re.IGNORECASE)

# 列名映射：支持多种可能的表头写法
CONTENT_COL_NAMES  = ["内容正文"]
TITLE_COL_NAMES    = ["内容标题", "标题"]
TOKEN_COL_NAMES    = ["URL_Token", "url_token", "token", "Token"]


def find_col(headers: list, candidates: list) -> int:
    """返回第一个匹配候选名的列索引（0-based），找不到返回 -1。"""
    for name in candidates:
        if name in headers:
            return headers.index(name)
    return -1


def extract_first_image(input_path: str, output_path: str = None) -> dict:
    if output_path is None:
        p = Path(input_path)
        output_path = str(p.parent / (p.stem + "_output" + p.suffix))

    wb_in = openpyxl.load_workbook(input_path)
    ws_in = wb_in.active

    headers = [cell.value for cell in ws_in[1]]

    col_content = find_col(headers, CONTENT_COL_NAMES)
    col_title   = find_col(headers, TITLE_COL_NAMES)
    col_token   = find_col(headers, TOKEN_COL_NAMES)

    if col_content == -1:
        raise ValueError(f"未找到「内容正文」列，当前表头：{headers}")

    wb_out = openpyxl.Workbook()
    ws_out = wb_out.active
    ws_out.title = "首图提取"
    ws_out.append(["内容标题", "URL_Token", "首图链接"])

    hit = 0
    empty = 0

    for row in ws_in.iter_rows(min_row=2, values_only=True):
        title   = row[col_title]   if col_title   != -1 else ""
        token   = row[col_token]   if col_token   != -1 else ""
        content = row[col_content] if col_content != -1 else ""

        first_img = ""
        if content and isinstance(content, str):
            m = IMG_SRC.search(content)
            if m:
                first_img = m.group(1)
                hit += 1
            else:
                empty += 1
        else:
            empty += 1

        ws_out.append([title, token, first_img])

    wb_out.save(output_path)
    total = ws_in.max_row - 1
    return {"output": output_path, "hit": hit, "empty": empty, "total": total}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python extract_first_image.py <input.xlsx> [output.xlsx]")
        sys.exit(1)

    inp = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else None
    result = extract_first_image(inp, out)
    print(f"处理完成：共 {result['total']} 条，提取首图 {result['hit']} 条，无图 {result['empty']} 条")
    print(f"输出文件：{result['output']}")
