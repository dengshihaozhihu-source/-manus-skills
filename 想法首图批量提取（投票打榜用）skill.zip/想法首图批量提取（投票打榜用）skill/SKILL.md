---
name: extract-first-image
description: 从 Excel 表格「内容正文」列的 HTML 正文中提取每行首图链接，输出「内容标题 / URL_Token / 首图链接」三列新表格。适用场景：用户上传含知乎/其他平台 HTML 正文的 Excel（列数、列序不固定），需要批量导出每条内容的封面图或首图 URL。
---

# Extract First Image

从 Excel「内容正文」列 HTML 正文中提取首图链接，输出标题-token-首图链接三列新表格。

## 执行流程

1. 接收用户上传的 Excel 文件（列数、列序不限，只要表头含「内容正文」即可）。
2. 运行脚本，自动定位「内容正文」「内容标题」「URL_Token」列，提取每行首图写入新文件。
3. 将输出文件发送给用户，告知提取数量统计。

## 运行脚本

```bash
python3.11 /home/ubuntu/skills/extract-first-image/scripts/extract_first_image.py <input.xlsx> [output.xlsx]
```

若不指定 `output.xlsx`，脚本自动在原文件名后加 `_output` 保存。

## 注意事项

- 脚本自动按表头名定位列，无需关心列序。
- 图片匹配正则：`<img[^>]+src=["']?(https?://[^"'>\s]+)["']?`，覆盖单引号、双引号及无引号三种写法。
- 若某行「内容正文」为空或无 `<img>` 标签，「首图链接」列写入空字符串。
- 若表头中找不到「内容正文」列，脚本报错并列出当前所有表头，便于排查。
- 若用户的图片链接格式不是标准 HTML `<img src>`（如 Markdown `![]()` 或纯 URL），需先检查实际格式，必要时调整正则。
