---
name: zhihu-wgp-generator
description: 为「@答主评审团」的「吃瓜娱乐化」系列，根据知乎问题链接自动生成小绿书图文。支持新版「霓虹液态玻璃」视觉风格（v2），封面杂志感，内容卡信息图感，深色底+渐变霓虹色。
---

# 知乎吃瓜小绿书生成器

**用途**：为「@答主评审团」的「吃瓜娱乐化」系列，根据知乎问题链接自动生成小绿书图文。

**触发条件**：用户提供一个或多个知乎问题链接，并要求制作「吃瓜娱乐化」系列小绿书。

---

## ⚡ 执行前必读：四大高频失误（每次任务开始前对照检查）

### 失误 1：Logo base64 双重前缀

`templates/*_b64.txt` 文件内容**已经包含** `data:image/png;base64,` 前缀。脚本读取后**直接使用**，不得再拼接前缀。

```python
# ❌ 错误
LOGO_B64 = "data:image/png;base64," + open("templates/logo_dzzpt_white_b64.txt").read().strip()

# ✅ 正确
LOGO_B64 = open("templates/logo_dzzpt_white_b64.txt").read().strip()
```

### 失误 2：配图用 cover 裁切导致文字截断

用户提供的配图（手机截图、公告截图等）**不能用 `object-fit: cover`**，必须完整显示。

```html
<!-- ❌ 错误 -->
<img src="..." style="width:100%; height:400px; object-fit:cover;">

<!-- ✅ 正确 -->
<img src="..." style="width:100%; height:auto;">
```

### 失误 3：flex:1 撑展导致卡片内部空白

内容行数少但容器被 `flex:1` 撑高时出现大片空白。解法：让卡片高度自适应内容，不用 `flex:1`。

### 失误 4：字号低于最小限制

**任何文字字号不得低于 32px**（含注释、来源、标签等），SVG 内文字不得低于 26px。

---

## 视觉规范 v2（默认使用此版本）

### 风格定位

「霓虹液态玻璃」—— 年轻有辨识度，轻松幽默，去 AI 感。封面走杂志感大图强排版，内容卡走信息可视化路线。

### 配色系统

| 用途 | 色值 |
|------|------|
| 主背景 | `#0d0d1a`（深夜蓝黑） |
| 次背景 | `#12121f` |
| 玻璃卡片背景 | `rgba(255,255,255,0.07)` |
| 玻璃卡片边框 | `rgba(255,255,255,0.12)` |
| 霓虹蓝 | `#4d95ff` |
| 霓虹紫 | `#b06aff` |
| 霓虹绿 | `#00e5a0` |
| 霓虹橙 | `#ff7a3d` |
| 霓虹粉 | `#ff4d8d` |

每张卡片选 1~2 个霓虹色作为主题色，标题渐变、标签胶囊、分割线均使用该色。

### 字体系统（全部使用系统内置 Noto 字体）

| 用途 | 字体 | 字重 | 字号 |
|------|------|------|------|
| 封面超大展示标题 | Noto Sans CJK SC | 900（Black） | 80~100px |
| 大标题 | Noto Sans CJK SC | 700（Bold） | 52~64px |
| 小标题 / 标签 | Noto Sans CJK SC | 500（Medium） | 34~40px |
| 正文 | Noto Sans CJK SC | 400（Regular） | 34~36px |
| 金句 / 引用 | Noto Serif CJK SC | 500（Medium）+ italic | 34~38px |
| 注释 / 来源 | Noto Sans CJK SC | 300（Light） | 32px（最小值） |

**最小字号硬限制：32px。任何文字不得低于此值。**

### 布局规范

- 尺寸：1150×1500px，deviceScaleFactor: 2
- 无页码（不显示「xx/07」类页码）
- Logo：左上角，`height:52px; width:auto`，深色背景用白色版
- 水印：右下角 `@答主评审团`，32px，opacity: 0.22
- 主内容区 padding：`0 52px 52px`，gap: `20~24px`

### 核心 CSS 组件

```css
/* 玻璃卡片 */
.glass {
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 24px;
    backdrop-filter: blur(20px);
}

/* 霓虹标签胶囊 */
.tag-neon {
    display: inline-block;
    padding: 8px 22px;
    border-radius: 999px;
    font-size: 32px;
    font-weight: 600;
}

/* 渐变文字 */
.grad-text-blue {
    background: linear-gradient(135deg, #4d95ff, #b06aff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* 光晕装饰 */
.glow-orb {
    position: absolute;
    border-radius: 50%;
    filter: blur(80px);
    pointer-events: none;
    z-index: 0;
}
```

### 信息可视化替代词云

不使用 Python wordcloud 库（效果不稳定，耗时长）。改用以下 SVG 内联方案：

- **关键词气泡**：`<ellipse>` + 文字，大小随重要性变化（主词 rx:155，次词 rx:145，小词 rx:80）
- **条形图**：`<rect>` + `<linearGradient>`，颜色用霓虹渐变
- **流程链条**：横排 `<rect>` 节点 + `→` 箭头

---

## 工作流程

### 1. 内容抓取

使用 `browser` 工具访问知乎问题链接，抓取问题标题、问题描述、前排 5~10 个高赞回答的文本内容、答主信息（昵称、简介）、回答配图（高清）。无需用户授权，直接以只读模式抓取公开内容。

**重要**：抓取时记录每个观点对应的答主昵称，最终总结卡必须在「来源说明」中列出所有被引用的答主。

### 2. 素材处理

从抓取到的回答配图中，筛选出与文案强相关、且清晰度足够高的图片，转为 base64 备用。

**配图处理规范**：

- 用户提供的配图使用 `width:100%; height:auto` 完整显示，**禁止裁切**。
- 如配图高度过长导致版面溢出，用 `max-height` 限制容器高度（不裁切图片内容本身）。
- 删除图片中的知乎 Logo 及「知乎 @用户名」图注。

### 3. 图片生成

参考 `/home/ubuntu/zhihu-wgp/generate_v2.py` 作为模板，将文案、答主信息、配图 base64 填入，生成 7 个 HTML 文件。

**Logo 读取方式**：

```python
SKILL_DIR = '/home/ubuntu/skills/zhihu-wgp-generator'
LOGO_WHITE_B64 = open(f'{SKILL_DIR}/templates/logo_dzzpt_white_b64.txt').read().strip()
LOGO_COLOR_B64 = open(f'{SKILL_DIR}/templates/logo_dzzpt_color_b64.txt').read().strip()
```

**7 张卡片结构参考**：

| 序号 | 主题 | 视觉重点 |
|------|------|----------|
| 01 | 封面 | 超大渐变标题 + 素材图 + 金句 |
| 02 | 痛点 / 背景 | 场景描述 + SVG 气泡可视化 |
| 03 | 核心功能 | 对话示例 + 素材图 |
| 04 | 生态 / 背景 | SVG 流程链条 + 素材图 |
| 05 | 竞争 / 对比 | 双列对比卡 + SVG 条形图 |
| 06 | 延伸视角 | 玻璃卡片引用 + 金句 |
| 07 | 总结 | 时代演进卡 + 核心金句 + 来源说明 |

### 4. 截图渲染

参考 `/home/ubuntu/zhihu-wgp/screenshot_v2.js` 作为截图脚本模板。

关键参数：`viewport: { width: 1150, height: 1500, deviceScaleFactor: 2 }`

**截图后立即逐张检查**，发现问题当场修复。

### 4.5 品牌名处理（负面新闻专项）

当事件涉及品牌负面（如产品造假、质量问题、违规行为），**必须对涉事品牌名进行打码处理**：

- 替换规则：保留品牌名首字或末字，其余替换为「某」，例如：IF → 某F、盒马 → 盒某。
- 图片和文案中的品牌名须**同步替换**，不得遗漏。

### 5. 文案撰写

根据抓取的内容，提炼核心观点和槽点，撰写一篇 ≤300 字的精简文案。（一定注意不要超过 300 字，尽量简洁精炼，你需要的不是把事情说清楚，而是作为图片内容的补充，引导大家去看图片或者，补充说明图片中已有的信息即可）

**文案风格规范**：

- 轻松、网感、第三方旁观者口吻，好玩不严肃
- 不体现知乎浏览量、回答数、赞数、链接等数据
- 禁止频繁使用「就像知友说的」等引导语，每篇最多出现 1 次

### 5.5 最终总结卡「知友共识」规范

最后一张卡片的金句必须**直接点名定性**，给出明确结论，禁止使用模糊表达：

- ✅ 正确：「这不叫「功能升级」，这叫「交互革命」」
- ❌ 错误：「背后的故事可不止三个字」（模糊、无结论）

最后一张卡片底部必须有「观点来源」说明，列出所有被引用的答主昵称及其身份标签。

### 6. 交付

交付 7 张处理完成的 PNG 图片和一篇 Markdown 格式的文案。

---

## 脚本与资源

| 文件 | 用途 |
|------|------|
| `templates/logo_dzzpt_white_b64.txt` | 白色版 Logo base64（深色背景用，内容已含 data:image 前缀，直接使用） |
| `templates/logo_dzzpt_color_b64.txt` | 彩色版 Logo base64（浅色背景备用，同上） |

**参考脚本**（不在 skill 目录内，但可直接复用）：

- `/home/ubuntu/zhihu-wgp/generate_v2.py`：完整的 v2 风格 HTML 生成脚本，包含所有 CSS 组件和 7 张卡片模板
- `/home/ubuntu/zhihu-wgp/screenshot_v2.js`：Puppeteer 截图脚本

新任务时，复制上述脚本到新工作目录，替换内容变量即可。
