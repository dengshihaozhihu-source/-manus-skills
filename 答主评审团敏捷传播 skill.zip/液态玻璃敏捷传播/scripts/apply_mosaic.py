"""
对含人像的图片，在双眼区域加毛玻璃横条马赛克。
策略：用 OpenCV Haar cascade 检测人脸，取眼睛区域（脸高约 25%~45% 位置）
加一条横向毛玻璃条（高度约脸高 20%）。
如果检测不到人脸，则跳过该图片。
"""

import cv2
import numpy as np
from PIL import Image, ImageFilter
import os

OUTPUT_DIR = '/home/ubuntu/wgp_project/output'

# 含人像的图片
TARGET_IMAGES = [
    '01_cover.png',
    '03_azonker.png',
    '04_reactions.png',
    '06_analysis.png',
]

# 下载 Haar cascade（如果不存在）
CASCADE_PATH = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(CASCADE_PATH)

def apply_frosted_bar(img_pil, x, y, w, h):
    """在图片 img_pil 的 (x,y,w,h) 区域加毛玻璃横条"""
    img_array = np.array(img_pil)
    
    # 裁出区域
    region = img_pil.crop((x, y, x + w, y + h))
    
    # 毛玻璃效果：强模糊 + 半透明白色叠加
    blurred = region.filter(ImageFilter.GaussianBlur(radius=18))
    
    # 叠加半透明白色磨砂层
    overlay = Image.new('RGBA', region.size, (255, 255, 255, 80))
    blurred_rgba = blurred.convert('RGBA')
    frosted = Image.alpha_composite(blurred_rgba, overlay).convert('RGB')
    
    # 贴回原图
    result = img_pil.copy()
    result.paste(frosted, (x, y))
    return result

def process_image(filename):
    path = os.path.join(OUTPUT_DIR, filename)
    if not os.path.exists(path):
        print(f"  SKIP (not found): {filename}")
        return
    
    img_pil = Image.open(path).convert('RGB')
    img_cv = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
    
    # 检测人脸（多尺度，宽松参数）
    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=4,
        minSize=(60, 60),
        flags=cv2.CASCADE_SCALE_IMAGE
    )
    
    if len(faces) == 0:
        print(f"  NO FACE detected: {filename}, skipping")
        return
    
    print(f"  {filename}: {len(faces)} face(s) detected")
    
    result = img_pil.copy()
    img_w, img_h = img_pil.size
    
    for (fx, fy, fw, fh) in faces:
        # 眼睛横条：脸部顶部往下 22%~42% 的位置，横向延伸到整张图宽度
        eye_y_start = fy + int(fh * 0.22)
        eye_y_end   = fy + int(fh * 0.42)
        bar_h = eye_y_end - eye_y_start
        
        # 横条宽度：从图片左边到右边（全宽横条）
        bar_x = 0
        bar_w = img_w
        
        # 确保不超出图片边界
        eye_y_start = max(0, eye_y_start)
        eye_y_end   = min(img_h, eye_y_end)
        bar_h = eye_y_end - eye_y_start
        
        if bar_h <= 0:
            continue
        
        result = apply_frosted_bar(result, bar_x, eye_y_start, bar_w, bar_h)
        print(f"    -> bar at y={eye_y_start}~{eye_y_end}, h={bar_h}px (full width)")
    
    result.save(path)
    print(f"  SAVED: {filename}")

print("=== 人像马赛克处理 ===")
for fname in TARGET_IMAGES:
    print(f"\n处理: {fname}")
    process_image(fname)

print("\n=== 完成 ===")
