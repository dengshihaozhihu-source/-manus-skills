#!/usr/bin/env python3
"""
从 logo_raw-1.png 中裁切横版 Logo（蓝色图标 + 答主评审团文字横排），
并生成白色版本，分别保存为：
  templates/logo_horizontal_color.png  — 彩色版（深色背景用）
  templates/logo_horizontal_white.png  — 白色版（深色背景用）
  templates/logo_horizontal_dark.png   — 深色版（浅色背景用）
"""

from PIL import Image, ImageOps
import numpy as np
import os

BASE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = os.path.join(BASE, '..', 'templates')

src = Image.open(os.path.join(TEMPLATES, 'logo_raw-1.png')).convert('RGBA')
w, h = src.size
print(f"原图尺寸: {w}x{h}")

# 右侧横版 Logo（第三行右侧，蓝色图标 + 答主评审团 + VOICES OF INSIGHT）
# 根据目视估算裁切区域（比例坐标）
# 第三行约在 y: 55%~80%，右侧两个版本约在 x: 55%~100%
# 取较小的那个（最右侧，纯横排无 VOICES OF INSIGHT 字样的版本）
# 即第三行最右侧版本：x 约 73%~100%, y 约 55%~72%

crop_box = (
    int(w * 0.725),
    int(h * 0.545),
    int(w * 1.0),
    int(h * 0.72),
)
logo_color = src.crop(crop_box)
print(f"裁切尺寸: {logo_color.size}")

# 去除多余白边（自动裁剪透明/白色边缘）
bg = Image.new('RGBA', logo_color.size, (255, 255, 255, 255))
bg.paste(logo_color, mask=logo_color.split()[3])
arr = np.array(bg.convert('RGB'))
# 找非白色像素范围（用 RGBA alpha 通道判断）
alpha_ch = np.array(logo_color)[:, :, 3]
mask = alpha_ch > 10
rows = np.any(mask, axis=1)
cols = np.any(mask, axis=0)
if not rows.any() or not cols.any():
    # fallback: 用 RGB 判断非白色
    mask = ~((arr[:, :, 0] > 240) & (arr[:, :, 1] > 240) & (arr[:, :, 2] > 240))
    rows = np.any(mask, axis=1)
    cols = np.any(mask, axis=0)
rmin, rmax = np.where(rows)[0][[0, -1]]
cmin, cmax = np.where(cols)[0][[0, -1]]
pad = 20
rmin = max(0, rmin - pad)
rmax = min(logo_color.height, rmax + pad)
cmin = max(0, cmin - pad)
cmax = min(logo_color.width, cmax + pad)
logo_color = logo_color.crop((cmin, rmin, cmax, rmax))
print(f"去白边后尺寸: {logo_color.size}")

# 保存彩色版（透明背景）
out_color = os.path.join(TEMPLATES, 'logo_horizontal_color.png')
logo_color.save(out_color)
print(f"保存: {out_color}")

# 白色版：将所有非透明像素改为白色
arr_rgba = np.array(logo_color)
alpha = arr_rgba[:, :, 3]
white_arr = np.ones_like(arr_rgba) * 255
white_arr[:, :, 3] = alpha
logo_white = Image.fromarray(white_arr.astype(np.uint8), 'RGBA')
out_white = os.path.join(TEMPLATES, 'logo_horizontal_white.png')
logo_white.save(out_white)
print(f"保存: {out_white}")

# 深色版（黑色）：将所有非透明像素改为深色 #1a1a1a
dark_arr = np.zeros_like(arr_rgba)
dark_arr[:, :, 0] = 26
dark_arr[:, :, 1] = 26
dark_arr[:, :, 2] = 26
dark_arr[:, :, 3] = alpha
logo_dark = Image.fromarray(dark_arr.astype(np.uint8), 'RGBA')
out_dark = os.path.join(TEMPLATES, 'logo_horizontal_dark.png')
logo_dark.save(out_dark)
print(f"保存: {out_dark}")

print("完成！")
