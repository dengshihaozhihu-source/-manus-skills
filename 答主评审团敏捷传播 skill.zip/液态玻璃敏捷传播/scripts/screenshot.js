/**
 * 小绿书截图脚本
 * 用法：node screenshot.js <html_dir> <output_dir> [page1,page2,...]
 *   html_dir:   HTML 文件所在目录（绝对路径）
 *   output_dir: PNG 输出目录（绝对路径，不存在时自动创建）
 *   page_names: 可选，逗号分隔的页面名列表，默认为 01_cover,02_event,...,07_summary
 *
 * 示例：
 *   node screenshot.js /home/ubuntu/wgp_oppo/output /home/ubuntu/wgp_oppo/output
 *   node screenshot.js /home/ubuntu/wgp_oppo/output /home/ubuntu/wgp_oppo/output 01_cover,02_chip,07_summary
 */

const puppeteer = require('/home/ubuntu/node_modules/.pnpm/puppeteer-core@24.38.0/node_modules/puppeteer-core');
const path = require('path');
const fs = require('fs');

// ── 参数解析 ──────────────────────────────────────────────
const args = process.argv.slice(2);
const HTML_DIR   = args[0] || path.join(__dirname, '..', 'output');
const OUTPUT_DIR = args[1] || HTML_DIR;
const DEFAULT_PAGES = ['01_cover','02_event','03_content','04_content','05_content','06_comment','07_summary'];
const pages = args[2] ? args[2].split(',') : DEFAULT_PAGES;

// 输出目录不存在时自动创建
if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// ── 截图 ──────────────────────────────────────────────────
(async () => {
    const browser = await puppeteer.launch({
        headless: 'new',
        executablePath: '/usr/bin/chromium-browser',
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-web-security']
    });

    for (const name of pages) {
        const htmlPath = path.join(HTML_DIR, `${name}.html`);
        if (!fs.existsSync(htmlPath)) {
            console.warn(`[SKIP] HTML 文件不存在: ${htmlPath}`);
            continue;
        }

        const page = await browser.newPage();
        await page.setViewport({ width: 1150, height: 1500, deviceScaleFactor: 2 });
        await page.goto(`file://${htmlPath}`, { waitUntil: 'networkidle0' });
        await new Promise(r => setTimeout(r, 600));  // 等待字体和图片渲染完成

        const outPath = path.join(OUTPUT_DIR, `${name}.png`);
        await page.screenshot({ path: outPath, fullPage: false });
        console.log(`[OK] ${outPath}`);
        await page.close();
    }

    await browser.close();
    console.log('All screenshots done!');
})();
