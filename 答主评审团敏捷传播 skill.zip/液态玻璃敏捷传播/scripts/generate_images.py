#!/usr/bin/env python3
"""
「吃瓜娱乐化」新视觉系列图片生成脚本
尺寸: 1150x1500
主色: 知乎黄 #ffd100 + 知乎蓝 #056de8
风格: 轻松、网感、年轻人喜欢

【防错说明 — 每次使用前必读】
1. Logo base64 文件（*_b64.txt）内容已含 data:image/png;base64, 前缀，直接读取使用，禁止再拼接前缀。
2. 用户提供的截图类配图（手机截图、公告截图等）必须用 width:100%; height:auto 完整显示，
   禁止使用 object-fit:cover，会截断文字。
3. 内容少的卡片禁止用 flex:1 撑展，应让容器高度自适应内容，空白集中在卡片外部。
"""

import base64, os, sys

# ============================================================
# Logo base64 加载（_b64.txt 文件内容已含 data:image 前缀，直接使用）
# ============================================================
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATES_DIR = os.path.join(SKILL_DIR, 'templates')

def load_logo(filename):
    """读取 logo base64 文件，文件内容已含 data:image/png;base64, 前缀，直接返回。"""
    path = os.path.join(TEMPLATES_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(f'Logo 文件不存在: {path}')
    with open(path) as f:
        content = f.read().strip()
    # 防御性检查：确保不会双重拼接前缀
    if not content.startswith('data:image'):
        raise ValueError(f'Logo 文件格式异常，应以 data:image 开头: {path}')
    return content

LOGO_COLOR_B64 = load_logo('logo_horizontal_color_b64.txt')   # 浅色/黄色背景用
LOGO_WHITE_B64 = load_logo('logo_horizontal_white_b64.txt')   # 深色背景用
LOGO_DARK_B64  = load_logo('logo_horizontal_dark_b64.txt')    # 备用

# ============================================================
# 配图 base64 加载（用户提供的配图，不含 data:image 前缀，需手动拼接）
# ============================================================
def load_img_b64(path):
    """
    读取配图 base64 文件。
    注意：配图 txt 文件内容不含 data:image 前缀，需要手动拼接。
    与 load_logo() 的区别：logo 文件已含前缀，配图文件不含。
    """
    if not os.path.exists(path):
        return ''
    with open(path) as f:
        content = f.read().strip()
    if content.startswith('data:image'):
        return content  # 已含前缀，直接返回
    return f'data:image/png;base64,{content}'

# ============================================================
# 输出目录（从命令行参数读取，默认为 ./output）
# ============================================================
OUTPUT_DIR = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================
# 公共 CSS
# 关键默认参数说明：
# - .img-container img 不设置 object-fit，由各卡片按需覆盖
# - 截图类配图（手机截图）用 width:100%; height:auto（完整显示）
# - 非截图配图（风景照、产品图）可用 object-fit:cover（填充容器）
# - .tag 字号 ≥30px（移动端最低标准）
# - 正文字号 ≥32px
# ============================================================
COMMON_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    width: 1150px;
    height: 1500px;
    overflow: hidden;
    font-family: 'PingFang SC', 'Noto Sans SC', 'Microsoft YaHei', sans-serif;
    background: #ffd100;
    position: relative;
}

/* 背景装饰波点 */
.bg-dots {
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background-image: radial-gradient(circle, rgba(0,0,0,0.06) 2px, transparent 2px);
    background-size: 36px 36px;
    pointer-events: none;
    z-index: 0;
}

/* 顶部 Logo 栏（默认黄色背景，深色卡片需内联覆盖为深色背景） */
.logo-bar {
    position: relative;
    z-index: 10;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 44px 56px 36px;
    background: transparent;
}

/* 页码 */
.page-num {
    font-size: 28px;
    color: rgba(0,0,0,0.35);
    font-weight: 500;
    letter-spacing: 1px;
}

/* 主内容区 */
.main {
    position: relative;
    z-index: 5;
    padding: 0 56px 48px;
    height: calc(1500px - 144px);
    display: flex;
    flex-direction: column;
}

/* 白卡 */
.card {
    background: #fff;
    border-radius: 24px;
    padding: 44px 48px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.10);
}

/* 黑色强调卡 */
.card-dark {
    background: #1a1a1a;
    border-radius: 24px;
    padding: 44px 48px;
    color: #fff;
}

/* 知乎蓝高亮块 */
.highlight-blue {
    background: #056de8;
    border-radius: 16px;
    padding: 28px 36px;
    color: #fff;
}

/* 知乎黄高亮块 */
.highlight-yellow {
    background: #ffd100;
    border-radius: 16px;
    padding: 24px 32px;
    color: #1a1a1a;
}

/* 引用气泡 */
.quote-bubble {
    background: #f0f6ff;
    border-left: 6px solid #056de8;
    border-radius: 0 16px 16px 0;
    padding: 24px 28px;
    margin: 16px 0;
}

/* 答主信息行 */
.author-row {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 20px;
}
.author-avatar {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background: #056de8;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: 700;
    color: #fff;
    flex-shrink: 0;
}
.author-name {
    font-size: 32px;
    font-weight: 700;
    color: #1a1a1a;
}
.author-votes {
    margin-left: auto;
    font-size: 28px;
    color: #056de8;
    font-weight: 600;
}

/* 标签（最低 30px，移动端可读） */
.tag {
    display: inline-block;
    background: #056de8;
    color: #fff;
    font-size: 30px;
    padding: 8px 20px;
    border-radius: 8px;
    font-weight: 600;
}
.tag-yellow {
    background: #ffd100;
    color: #1a1a1a;
}
.tag-red {
    background: #ff3b30;
    color: #fff;
}

/* 图片容器
   重要：不在此处设置 object-fit，由各卡片按需覆盖：
   - 截图类配图（手机截图、公告截图）：width:100%; height:auto（完整显示，禁止 cover）
   - 风景/产品图（需填充容器）：object-fit:cover
*/
.img-container {
    border-radius: 20px;
    overflow: hidden;
    background: #eee;
    position: relative;
}
.img-container img {
    width: 100%;
    display: block;
    /* height 和 object-fit 由各卡片按需设置，此处不设默认值 */
}

/* 截图类配图专用样式（完整显示，不裁切） */
.img-screenshot {
    border-radius: 20px;
    overflow: hidden;
    background: #f5f5f5;
}
.img-screenshot img {
    width: 100%;
    height: auto;   /* 高度自适应，完整显示所有文字 */
    display: block;
}

.img-caption {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(transparent, rgba(0,0,0,0.7));
    color: #fff;
    font-size: 26px;
    padding: 20px 24px 16px;
}

/* 底部水印 */
.watermark {
    position: absolute;
    bottom: 32px;
    right: 56px;
    font-size: 24px;
    color: rgba(0,0,0,0.3);
    z-index: 10;
}
"""

# ============================================================
# Logo 栏 HTML 片段生成函数
# 用法：
#   浅色/黄色背景卡片：logo_bar_html('01 / 07', dark=False)
#   深色背景卡片：logo_bar_html('01 / 07', dark=True)
# ============================================================
def logo_bar_html(page_num, dark=False):
    """生成顶部 logo 栏 HTML。dark=True 时使用白色 logo + 深色背景。"""
    logo = LOGO_WHITE_B64 if dark else LOGO_COLOR_B64
    bg_style = 'background: #1a1a1a;' if dark else ''
    num_color = 'color: rgba(255,255,255,0.35);' if dark else 'color: rgba(0,0,0,0.35);'
    return f'''<div class="logo-bar" style="{bg_style}">
    <img src="{logo}" style="height:50px; width:auto;" alt="答主评审团">
    <div class="page-num" style="{num_color}">{page_num}</div>
</div>'''

# ============================================================
# 示例：图 1 封面（深色背景）
# ============================================================
html_01 = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
{COMMON_CSS}
body {{ background: linear-gradient(160deg, #1a1a1a 0%, #2d2d2d 100%); }}
</style>
</head>
<body>
<div class="bg-dots" style="background-image: radial-gradient(circle, rgba(255,255,255,0.04) 2px, transparent 2px); background-size: 36px 36px;"></div>

{logo_bar_html('01 / 07', dark=True)}

<div class="main" style="justify-content: center; gap: 36px; padding-top: 20px;">
    <div style="display: inline-block; background: #ffd100; color: #1a1a1a; font-size: 30px; font-weight: 700; padding: 10px 24px; border-radius: 10px;">
        🔥 知友热议
    </div>
    <div style="font-size: 88px; font-weight: 900; color: #fff; line-height: 1.1; letter-spacing: -2px;">
        在此填写<br>封面大标题
    </div>
    <div style="font-size: 36px; color: rgba(255,255,255,0.7); line-height: 1.6;">
        副标题说明文字
    </div>
    <div style="background: rgba(255,209,0,0.15); border: 2px solid rgba(255,209,0,0.4); border-radius: 20px; padding: 32px 40px; margin-top: 16px;">
        <div style="font-size: 36px; color: #ffd100; line-height: 1.7; font-style: italic;">
            「在此填写封面引用金句」
        </div>
        <div style="font-size: 28px; color: rgba(255,255,255,0.5); margin-top: 12px;">—— @答主昵称</div>
    </div>
</div>
<div class="watermark" style="color: rgba(255,255,255,0.2);">@答主评审团</div>
</body></html>"""

# ============================================================
# 示例：图 2 事件背景（浅色背景 + 截图类配图）
# 截图类配图使用 .img-screenshot 类，完整显示不裁切
# ============================================================
html_02 = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
{COMMON_CSS}
</style>
</head>
<body>
<div class="bg-dots"></div>
{logo_bar_html('02 / 07', dark=False)}

<div class="main" style="padding-top: 0; gap: 20px;">
    <div class="card" style="display: flex; flex-direction: column; gap: 20px;">
        <div class="tag">事件背景</div>
        <div style="font-size: 36px; font-weight: 700; color: #1a1a1a; line-height: 1.4;">
            在此填写事件标题
        </div>
        <div style="font-size: 34px; color: #444; line-height: 1.7;">
            在此填写事件描述正文，字数控制在 80 字以内。
        </div>

        <!-- 截图类配图：使用 img-screenshot 类，完整显示，不裁切 -->
        <div class="img-screenshot">
            <img src="[配图 base64]" alt="配图说明">
        </div>
    </div>
</div>
<div class="watermark">@答主评审团</div>
</body></html>"""

# ============================================================
# 示例：图 7 总结卡（深色背景）
# ============================================================
html_07 = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
{COMMON_CSS}
body {{ background: #1a1a1a; }}
</style>
</head>
<body>
<div class="bg-dots" style="background-image: radial-gradient(circle, rgba(255,255,255,0.04) 2px, transparent 2px);"></div>
{logo_bar_html('07 / 07', dark=True)}

<div class="main" style="padding-top: 0; gap: 24px;">
    <div style="font-size: 56px; font-weight: 900; color: #ffd100; text-align: center; padding: 16px 0;">
        知友共识
    </div>

    <!-- 知友评论截图（如有）：使用 img-screenshot 完整显示 -->
    <div class="img-screenshot">
        <img src="[评论截图 base64]" alt="知友评论">
    </div>

    <!-- 三条结论（高度自适应，不用 flex:1） -->
    <div style="display: flex; flex-direction: column; gap: 16px;">
        <div class="card-dark" style="border-left: 6px solid #ffd100; padding: 28px 36px;">
            <div style="font-size: 30px; color: #ffd100; font-weight: 700; margin-bottom: 10px;">结论一标题</div>
            <div style="font-size: 34px; color: #fff; line-height: 1.6;">结论一正文，直接定性，不模糊。</div>
        </div>
        <div class="card-dark" style="border-left: 6px solid #056de8; padding: 28px 36px;">
            <div style="font-size: 30px; color: #56a0ff; font-weight: 700; margin-bottom: 10px;">结论二标题</div>
            <div style="font-size: 34px; color: #fff; line-height: 1.6;">结论二正文，直接定性，不模糊。</div>
        </div>
        <div class="card-dark" style="border-left: 6px solid #ff9500; padding: 28px 36px;">
            <div style="font-size: 30px; color: #ffb340; font-weight: 700; margin-bottom: 10px;">结论三标题</div>
            <div style="font-size: 34px; color: #fff; line-height: 1.6;">结论三正文，直接定性，不模糊。</div>
        </div>
    </div>
</div>
<div class="watermark" style="color: rgba(255,255,255,0.2);">@答主评审团</div>
</body></html>"""

# ============================================================
# 写入 HTML 文件（按实际任务替换 pages 列表）
# ============================================================
pages = [
    ('01_cover', html_01),
    ('02_event', html_02),
    # ('03_xxx', html_03),
    # ('04_xxx', html_04),
    # ('05_xxx', html_05),
    # ('06_xxx', html_06),
    ('07_summary', html_07),
]

for name, html in pages:
    path = f'{OUTPUT_DIR}/{name}.html'
    with open(path, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f'Written: {path}')

print('All HTML files generated!')
